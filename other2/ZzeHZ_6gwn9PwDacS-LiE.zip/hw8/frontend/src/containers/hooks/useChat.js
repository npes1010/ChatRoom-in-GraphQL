import { useState, useEffect, useRef, useContext, createContext } from 'react'
import { message } from 'antd'
import { useQuery, useMutation } from "@apollo/client";
import { CHATBOX_QUERY, CREATE_CHATBOX_MUTATION, CREATE_MESSAGE_MUTATION, MESSAGE_SUBSCRIPTION } from "../../graphql";
const LOCALSTORAGE_KEY = "save-me"
const savedMe = localStorage.getItem(LOCALSTORAGE_KEY)

const ChatContext = createContext({
    status: {},
    me: "",
    signedIn: false,
    messages: [],
    startChat: () => {},
    sendMessage: () => {},
    clearMessages: () => {},
})

// const client = new WebSocket("ws://localhost:4000/graphql")
// client.onopen = () => console.log('Backend socket server connected!')

const ChatProvider = (props) => {
    const [status, setStatus] = useState({})
    const [me, setMe] = useState(savedMe || "")
    const [signedIn, setSignedIn] = useState(false)
    const [messages, setMessages] = useState([])

    const [startChat] = useMutation(CREATE_CHATBOX_MUTATION)
    const [sendMessage] = useMutation(CREATE_MESSAGE_MUTATION)

    const displayStatus = (s) => {
        if(s.msg) {
            const {type, msg} = s
            const content = {
                content: msg, duration: 0.5
            }
            switch(type) {
                case 'success':
                    message.success(content)
                    break
                case 'error':
                    message.error(content)
                    break
                default:
                    message.warning(content)
            }
        }
    }

    // client.onmessage = (byteString) =>{
    //     const {data} = byteString
    //     const [task, payload] = JSON.parse(data)
    //     switch(task) {
    //         case "init": { 
    //             setMessages(payload)
    //             break
    //         }
    //         case "output" : {
    //             setMessages([...messages, payload])
    //             break
    //         }
    //         case "status": {
    //             setStatus(payload)
    //             break
    //         }
    //         case "clear": {
    //             setMessages([])
    //             break
    //         }
    //         default: break
    //     }
    // }
    const sendData = async(data) => {
        // await client.send(JSON.stringify(data))   
    }

    useEffect(() => {
        if(signedIn) {
            localStorage.setItem(LOCALSTORAGE_KEY, me)
        }
    }, [signedIn])

    
    return (
        <ChatContext.Provider
            value={{
                status,
                me,
                signedIn,
                messages,
                setMe,
                setSignedIn,
                startChat,
                sendMessage,
                // clearMessages,
                displayStatus
            }}
            {...props}
        />
    )
}

const useChat = () => useContext(ChatContext)

export {ChatProvider, useChat}


    // const startChat = async(name, to) => {
    //     console.log("name:", name, "to:", to)
    //     if(!name || !to) 
    //         throw new Error('name or to required.')
    //     await sendData(['CHAT', {name, to}])
    //     console.log("startChat")
    // }

    // const sendMessage = (name, to, body) => {
    //     console.log(name, to, body)
    //     if(!name|| !to || !body) 
    //         throw new Error('name or to or body required.')
    //     sendData(['MESSAGE', {name, to, body}])
    //     console.log("sendMessage")
    // }

    // const clearMessages = () => {
    //     sendData(["CLEAR",])
    //     console.log("clearMessage")
    // }