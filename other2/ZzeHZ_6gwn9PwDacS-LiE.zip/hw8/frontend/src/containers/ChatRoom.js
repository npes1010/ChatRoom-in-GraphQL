import React, { useEffect, useState, useRef } from 'react'
import { Tabs, Input, Tag } from 'antd'
import styled from 'styled-components'
import {useChat} from "./hooks/useChat"
import Title from '../components/Title'
import Message from '../components/Message'
import ChatModal from "../components/ChatModal"
import ChatBoxes from './ChatBoxes'

const ChatBoxesWrapper = styled(Tabs)`
    width: 100%;
    height: 300px;
    background: #eeeeee52;
    border-radius: 10px;
    margin: 20px;
    padding: 20px;
`;

const ChatBoxWrapper = styled.div`
    height: calc(240px - 36px);
    display: flex;
    flex-direction: column;
    overflow: auto;
`;

const FootRef = styled.div`
    height: 20px    
    `
const ChatRoom = () => {
    const {me, messages, startChat, sendMessage, displayStatus} = useChat()
    const [chatBoxes, setChatBoxes] = useState([]) //{label, children, key}
    const [activeKey, setActiveKey] = useState('')
    const [msg, setMsg] = useState('') // text input body
    const [msgSent, setMsgSent] = useState(false)
    const [modalOpen, setModalOpen] = useState(false)

    const nameFooter = useRef()

    const displayChat = (chat) => ( 
        chat.length === 0 ? (
            <p style={{ color: '#ccc' }}>
              No messages...
            </p>
        ) : (
        <ChatBoxWrapper>{
            // chat.map
            // (({name, body}, i) => 
            // (<Message isMe={name === me} message={body} key={i} />))
            chatBoxes.map((friend) => {
                return (
                    <ChatBoxes me={me} friend={friend} key={friend} />
                );
            })
        }
            <FootRef ref={nameFooter} />
        </ChatBoxWrapper> )
    )

    const extractChat = (friend) => {
        return displayChat
            (messages.filter
                (({name, body}) => ((name === friend) || (name === me))))
    }

    const create = (friend) => {
        if (chatBoxes.some((name) => name === friend))
            throw new Error(friend + "'s chat box has already opended");
        setChatBoxes([...chatBoxes, friend]);
        return friend;
    }

    const createChatBox = (friend) => {
        console.log("press plus buttoning")
        // const friend = nameFooter.current.state.value
        if (friend === "") {
			displayStatus({
				type: "error",
				msg: "Please enter username.",
			});
			return;
		}

		// FootRef.current.state.value = "";
        startChat({
			variables: {
				name1: me,
				name2: friend,
			},
		});

        setActiveKey(create(friend));
		setModalOpen(false);

        // if(chatBoxes.some(({key}) => key === friend)) {
        //     throw new Error(friend + "'s chat has already opened.")
        // }
        // const chat = extractChat(friend)
        // setChatBoxes([...chatBoxes,
        // { label: friend, children: chat, key: friend }])
        // setMsgSent(true)
        // return friend
    }

    const removeChatBox = (targetKey, activeKey) => {
        const index = chatBoxes.findIndex(({key}) => key === activeKey)
        const newChatBoxes = chatBoxes.filter(({key}) => key !== targetKey)
        setChatBoxes(newChatBoxes)

        return activeKey
            ? activeKey === targetKey
                ? index === 0
                    ? ""
                    : chatBoxes[index - 1].key
                : activeKey
            : ''
    }

    const ScrollToBottom = () => {
        nameFooter.current?.scrollIntoView
        ({ behavior: 'smooth', block: 'start' })
    }

    useEffect(() => {
        ScrollToBottom()
        setMsgSent(false)
    }, [msgSent])

    // const loading = async() => {
    //     console.log("start reloading")
    //     const chat = await extractChat(activeKey)
    //     console.log("🚀 ~ file: ChatRoom.js ~ line 96 ~ loading ~ chat", chat)
        
    //     setChatBoxes((previous_message) => {
    //         let newBox = previous_message.map((box) => {
    //             if(box.key === activeKey)
    //                 return {...box, children: chat}
    //             else
    //                 return box
    //         })
    //         return newBox
    //     })
    // }

    // useEffect(() => {
    //     loading()
    // }, [messages])

    return(<>
        <Title name={me}/>
        <>
            <ChatBoxesWrapper
                tabBarStyle={{height: '36px'}}
                type='editable-card'
                activeKey={activeKey}
                onChange={(key) => {
                    setActiveKey(key)
                    // startChat(me, key)
                    extractChat(key)
                    // loading()
                }}
                onEdit={(targetKey, action) => {
                    if(action === 'add')    
                        setModalOpen(true)
                    else if(action === 'remove'){
                        setActiveKey(removeChatBox(targetKey, activeKey))
                    }
                }}
                // items={chatBoxes}
            >
            </ChatBoxesWrapper>

            <ChatModal
                open={modalOpen}
                onCreate={async(friend) => {
                    createChatBox()
                //     setActiveKey(name)
                //     startChat(me, name)
                //     setModalOpen(false)
                }}
                onCancel={() => {
                    setModalOpen(false)
                }}
                inputRef={nameFooter} 
            />
        </>
        <Input.Search
            value={msg}
            onChange={(e) => setMsg(e.target.value)}
            enterButton="Send"
            placeholder="Type a message here..."
            onSearch={(msg) => {
                if (!msg ) { //|| !username
                    displayStatus({
                        type: 'error',
                        msg: 'Please enter a username and a message body.'
                    })
                    return
                }
                else if(activeKey === ''){
                    displayStatus({
                        type: 'error',
                        msg: 'Please add a chatbox first.',
                    })
                    setMsg('')
                    return
                }
                sendMessage({
                    variables:{
                        name: me,
                        to: activeKey,
                        body: msg
                    }
                })
                setMsg('')
                setMsgSent(true)
            }}
        />
    </>
    )   
}

export default ChatRoom