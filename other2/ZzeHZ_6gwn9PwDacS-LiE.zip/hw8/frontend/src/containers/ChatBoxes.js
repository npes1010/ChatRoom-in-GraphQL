import { useEffect, useRef } from "react";
import styled from "styled-components";
import { useQuery } from "@apollo/client";
import { CHATBOX_QUERY, MESSAGE_SUBSCRIPTION } from "../graphql";

const ChatBoxes = ({me, friend})  => {
    const msgFooter = useRef(null)

    const {data, loading, subscribeToMore } = useQuery(CHATBOX_QUERY, {
        variables:{
            name1: me,
            name2: friend
        }
    })

    const ScrollToBottom = () => {
        msgFooter.current?.scrollIntoView
        ({ behavior: 'smooth', block: 'start' })
    }

    useEffect(() => {
        ScrollToBottom();
    }, [data]);

    useEffect(() => {
        subscribeToMore({
            document: MESSAGE_SUBSCRIPTION,
            variables: {
                name1: me,
                name2: friend,
            },
            updateQuery: (prev, { subscriptionData }) => {
                if (!subscriptionData.data) return prev;
                const newMessage = subscriptionData.data.message.message;
                return {
                    ...prev,
                    chatBox: {
                        ...prev.chatBox,
                        messages: [...prev.chatBox.messages, newMessage],
                    },
                };
            },
        });
    }, [subscribeToMore]);
};
export default ChatBoxes;
