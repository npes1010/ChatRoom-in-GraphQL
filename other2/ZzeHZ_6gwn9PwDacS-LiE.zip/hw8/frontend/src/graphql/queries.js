import { gql } from '@apollo/client';

// 應該要有4個
// 1. query: given 兩個人的名字去query一個chatbox -> 得到所有對話紀錄
// 2. mutation createChatBox: 依據兩個人的名字去找chatbox，沒有的話就創建新的
// 3. mutation createMessages: 新增對話
// 4. subscribe chatbox: 依據兩人名字subscribe一個chatbox 收到變化後  更新前端

export const CHATBOX_QUERY = gql`
  query chatbox(
    $name: String!
  ) {
    chatbox (
      name: $name
    ) {
      name
      messages {
        sender
        body
      }
    }
  }
`;

