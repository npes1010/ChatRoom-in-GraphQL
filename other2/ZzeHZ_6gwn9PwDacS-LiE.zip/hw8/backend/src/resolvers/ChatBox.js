const ChatBox = {
    messages: (parent) => (parent.messages),
}
export default ChatBox