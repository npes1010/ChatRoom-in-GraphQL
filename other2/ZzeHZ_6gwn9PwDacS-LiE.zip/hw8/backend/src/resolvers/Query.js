const Query = {
  chatbox: async (parent, {name}, {ChatBoxModel}) => {
    if(!ChatBoxModel){
      console.log("couldn't connect to chatboxmodel")
    }
    if(!name){
      console.log("fill in name")
    }
    const box = await ChatBoxModel.findOne({name})
    if(!box){
      return await new ChatBoxModel({name}).save()
    }
    box.chatbox = []
    await box.save()
    return box
    // let messages = box.messages
    // let msg = []
    // messages.map(async(temp) => {
    //     let sender = temp.sender
    //     let body = temp.body
    //     msg.push({name: sender, body: body})
    // })
    // box.messages.push(msg);
    // await box.save();
  },
};
export default Query