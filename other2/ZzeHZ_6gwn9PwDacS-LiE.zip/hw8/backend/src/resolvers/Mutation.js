const makeName = (name, to) => {
  return [name, to].sort().join('_')
}

const Mutation = {
  createMessage: async (parent, { name, to, body }, {ChatBoxModel, pubsub}) => {
      const chatBoxName = makeName(name, to);
      console.log("name =", name)
      console.log("name =", to)
      let chatBox = await ChatBoxModel.findOne({name: chatBoxName})
      if(!chatBox){
        chatBox = await new ChatBoxModel({name: chatBoxName}).save()
        console.log("createMessage: create a new chatBox", chatBox)
      }
      const newMsg = { sender: name, body };
      console.log("newMsg = ", newMsg)
      chatBox.messages.push(newMsg);
      await chatBox.save();
      pubsub.publish(`chatBox ${chatBoxName}`, {
        message: newMsg,
      });
      return newMsg;
    },
  createChatBox: async(parent, {name1, name2}, {ChatBoxModel, pubsub}) => {
    const chatBoxName = makeName(name1, name2)
    console.log("name1 =", name1)
    console.log("name2 =", name2)
    let chatBox = await ChatBoxModel.findOne({name: chatBoxName})
    if(!chatBox){
      chatBox = await new ChatBoxModel({name: chatBoxName}).save()
    }
    console.log("open chatBox", chatBoxName)
    console.log(chatBox)
    pubsub.publish(`${chatBoxName}_opened`, {
      message: chatBox
    })
    return chatBox
  },
};

export default Mutation