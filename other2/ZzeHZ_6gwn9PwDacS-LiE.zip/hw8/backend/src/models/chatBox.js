import mongoose from "mongoose";
const Schema = mongoose.Schema

const ChatBoxSchema = new Schema({
    name: {  //chatbox_name
        type: String, 
        required: [true, 'Name field is required.'] 
    },
    messages: [{
        sender: String, body: String  }],
});

const ChatBoxModel = mongoose.model('ChatBox', ChatBoxSchema);

export default ChatBoxModel